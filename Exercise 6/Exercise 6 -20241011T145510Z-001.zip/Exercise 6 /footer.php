<footer style="text-align: center; padding: 20px; background-color: #f1f1f1; position: relative; bottom: 0; width: 100%; margin-top: auto; position: absolute;  left: 0; right: 0;  ">
    <p>&copy; 2024 Group 10. All rights reserved.</p>
    <p>GRP 10 Team Profile</p>
  </footer>